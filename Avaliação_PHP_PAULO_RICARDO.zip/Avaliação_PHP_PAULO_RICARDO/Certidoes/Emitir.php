<?php


        interface emitir{
            public function emite();
        

        }